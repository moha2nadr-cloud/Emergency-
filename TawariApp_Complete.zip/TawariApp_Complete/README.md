# تواري - تطبيق الطوارئ 🚨

## كيف تحصل على الـ APK من هاتفك فقط؟

### الخطوات (5 دقائق فقط):

**1. أنشئ حساب GitHub مجاني**
- افتح: https://github.com/signup
- أنشئ حساباً مجانياً

**2. أنشئ Repository جديد**
- اضغط على زر "+" ثم "New repository"
- سمّه: `TawariApp`
- اجعله **Private**
- اضغط "Create repository"

**3. ارفع ملفات المشروع**
- في صفحة الـ Repository اضغط "uploading an existing file"
- ارفع جميع الملفات والمجلدات (يمكنك ضغطهم في ZIP أولاً)

**4. ابدأ البناء التلقائي**
- اذهب لـ "Actions" في Repository
- سيبدأ البناء تلقائياً
- انتظر 3-5 دقائق ☕

**5. حمّل الـ APK**
- في "Actions" → اضغط على آخر Build
- في الأسفل ستجد "Artifacts"
- اضغط "TawariApp-Debug-APK" لتحميله!

---
بُني بـ ❤️ لخدمة المجتمع
